import yaml

with open('config-temp.yaml', 'rb') as file:
    clash_config = yaml.safe_load(file)

with open('glados.yaml', 'rb') as file:
    clash_glados = yaml.safe_load(file)

clash_config['proxies'] = clash_glados['proxies']
clash_config['proxy-groups'] = clash_glados['proxy-groups']
clash_config['rules'] = clash_glados['rules']

with open(r'../config.yaml', 'w') as file:
    documents = yaml.dump(clash_config, file)
