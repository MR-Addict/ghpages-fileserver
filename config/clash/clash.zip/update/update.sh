#! /bin/bash

cd /home/$USER/.config/clash/update

wget https://update.glados-config.com/clash/175988/b843614/14108/glados.yaml -O glados.yaml
python rewrite.py
